
import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { signupUser } from "../services/user"

export function Signup(){

//react hook is a function with start with use prifix is called for certain events example usestate

const [firstname, setFirstName] = useState('')
const [lastname, setLastName] = useState('')
const [email, setEmail] = useState('')
const [password, setPassword] = useState('')
const [ConfirmPassword, setConfirmPassword] = useState('')

//create the navigate function

const navigate = useNavigate() 

const onSignup = async () => {
    if (firstname.length == 0){
       alert('enter a first name')
} else if (lastname.length == 0){
   alert('enter a last name')
}
else if(email.length == 0 ){
 alert('enter a email')
}
else if(password.length == 0){
    alert('enter a password')
}
else if(ConfirmPassword.length == 0){
   alert('enter a confirm password')
}
else if(password != ConfirmPassword){
    alert('password does not match')
}
else {
   // make the api call
   
   const result = await signupUser(firstname, lastname, email, password)

   if (result['status'] == 'success'){
      alert.success('Successfully registered the user')
      navigate('/Login')
   }
   else {
    alert(result['error'])
   }
}
}

    return(
        <>
        <h1 className="title">Login</h1>

        <div className="row">
            <div className="col"></div>
            <div className="col">
            <div className="form">

            <div className="mb-3">
                <label htmlFor="">FirstName</label>
                <input onChange={(e) =>setFirstName(e.target.value)}
                 type="text"
                placeholder="firstname"
                className="form-control"/>
            </div>

            <div className="mb-3">
                <label htmlFor="">LastName</label>
                <input onChange ={(e) => setLastName(e.target.value)}
                type="text"
                placeholder="lastname"
                className="form-control"/>
            </div>
    
    


            <div className="mb-3">
                <label htmlFor="">Email</label>
                <input onChange={(e) => setEmail(e.target.value)}
                 type="email"
                placeholder="abc@text.com"
                className="form-control"/>
            </div>
    

       
            <div className="mb-3">
                <label htmlFor="">Password</label>
                <input onChange={(e) => setPassword(e.target.value)} 
                 type="password"
                placeholder="xxxxxxxxx"
                className="form-control"/>
            </div>

            <div className="mb-3">
                <label htmlFor="">ConfirmPassword</label>
                <input  onChange={(e) => setConfirmPassword(e.target.value)} 
                type="password"
                placeholder="xxxxxxxxx"
                className="form-control"/>
            </div>

            <div className="mb-3">
                <div>Already have an account? <Link to ='/Login'> Login Here! </Link></div>
                <button onClick={onSignup} className="btn btn-primary">Signup</button>
            </div>
            </div>
            </div>
            <div className="col"></div>
        </div>
       

       
         </>
    )
}

export default Signup