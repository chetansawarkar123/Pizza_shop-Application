create DATABASE pizza_shop;

USE pizza_shop;

--User

CREATE TABLE user (
    id INTEGER PRIMARY KEY auto_increment,
    firstname VARCHAR(50),
    lastname VARCHAR(50),
    email VARCHAR(50),
    password VARCHAR(50),
    createdTimestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP    
);

-- pizza

CREATE TABLE pizza (
    id INTEGER PRIMARY KEY auto_increment,
    name VARCHAR(50),
    details VARCHAR(1024),
    price FLOAT,
    image VARCHAR(100),
    createdTimestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT into pizza (name, details, price, image) VALUES ('Mixed pizza', 'Mixed pizza on wooden background', 149, 'pizza01.png'),
('Sliced pizza Margarita','Sliced pizza Margarita over wooden table. Top view, flat lay', 199, 'pizza02.png'),
('Margherita pizza with tomatoes','Margherita pizza with tomatoes and mozarella on wood background, top view',209,'pizza03.png'),
('Mediterranean Pizza','Mediterranean Pizza with mozarella on wood background', 249, 'pizza04.png');

--order

CREATE TABLE orderMaster (
    id INTEGER PRIMARY KEY auto_increment,
    userId INTEGER,
    totalAmount FLOAT,
    createdTimestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- order details 

CREATE TABLE orderDetails (
    id INTEGER PRIMARY KEY auto_increment,
    orderId INTEGER,
    pizzaId INTEGER,
    quantity INTEGER,
    totalAmount FLOAT,
    createdTimestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

--