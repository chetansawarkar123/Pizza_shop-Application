import { Link, useNavigate } from "react-router-dom"
import { useState } from "react"
import { LoginUser } from "../services/user"

 export function Signin() {

    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')

    const navigate = useNavigate()

    const onLogin = async () => {
        
     if(email.length == 0 ){
     alert('enter a email')
    }
    else if(password.length == 0){
        alert('enter a password')
    
    }
    else {
       // make the api call
       
       const result = await LoginUser(email, password)
    
       if (result['status'] == 'success'){

        //catch the token

        const token = result['data']['token']
        
          alert('Welcome to the nolx')
          navigate('/Home')
       }
       else {
        alert(result['error'])
       }
    }
    }
    

    return (

        <>
        <h1 className="title">Signin</h1>

        <div className="row">
            <div className="col"></div>
            <div className="col">

            <div className="form">
             <div className="mb-3">
                <label htmlFor="">Email</label>
                <input onChange={(e) => setEmail(e.target.value)}
                 type="email"
                placeholder="abc@text.com"
                className="form-control"/>
            </div>
    

       
            <div className="mb-3">
                <label htmlFor="">Password</label>
                <input onChange={(e) => setPassword(e.target.value)} 
                 type="password"
                placeholder="xxxxxxxxx"
                className="form-control"/>
            </div>

            <div className="mb-3">
                <div>Don't have an account? <Link to ='/Signup'> SignUp Here! </Link></div>
                <button onClick={onLogin} className="btn btn-primary">Signin</button>
            </div>
            </div>
            </div>
            <div className="col"></div>
        </div>
       

       
         </>

       
    )

 }

 export default Signin

