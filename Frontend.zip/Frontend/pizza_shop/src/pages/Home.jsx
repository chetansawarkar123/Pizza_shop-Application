import { useEffect, useState } from "react"
import Navbar from "../components/Navbar"
import { getAllOrders } from "../services/products"


export function Home() {
const [items, setItems] = useState([])

const loadAllOrders = async () =>
{
    const result = await getAllOrders()

    if(result['status'] == 'success'){
        setItems(result['data'])
    }
    else {
        alert(result['error'])
    }
}

//use effect hook use for simulating all componnet lifecycle

useEffect(() => {
    loadAllOrders()
},) 


    return(
        <>
        <Navbar/>
        <div className="container">
        <h1 className="title">Home</h1>

       
        </div>
      
        </>
    )
}

export default Home


