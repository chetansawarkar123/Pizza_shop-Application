import React, { useState } from 'react';


const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [order, setOrder] = useState({ name: '', date: '', price: '', image: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setOrder({ ...order, [name]: value });
  };

  const addOrder = () => {
    setOrders([...orders, order]);
    setOrder({ name: '', date: '', price: '', image: '' });
  };

  return (
    <div className="my-orders">
      <h1>My Orders</h1>
      <input type="text" name="name" value={order.name} placeholder="Product Name" onChange={handleChange} />
      <input type="date" name="date" value={order.date} placeholder="Order Date" onChange={handleChange} />
      <input type="text" name="price" value={order.price} placeholder="Price" onChange={handleChange} />
      <input type="text" name="image" value={order.image} placeholder="Image URL" onChange={handleChange} />
      <button onClick={addOrder}>Add Order</button>
      {orders.map((order, index) => (
        <div key={index} className="order-item">
          <img src={order.image} alt={order.name} className="item-image" />
          <div className="item-details">
            <h3>{order.name}</h3>
            <p>{order.date}</p>
            <p>{order.price}</p>
          </div>
          <button className="rating-button">Rate now</button>
        </div>
      ))}
    </div>
  );
};

export default Orders;
