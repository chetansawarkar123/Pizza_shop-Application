import { Route, Routes } from "react-router-dom";
import Signin from "./pages/Signin";
import Signup from "./pages/Signup";
import Home from "./pages/Home";
import Orders from "./pages/Orders";
import Cart from "./pages/Cart"
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';



function App() {
  return (
    <div className="container">
      <Routes>
        <Route index element = {<Signin/> }/>
        <Route path="/Signin" element = {<Signin/> }/>
        <Route path="/Signup" element = {<Signup/> }/>
        <Route path="/orders" element = {<Orders/>}/>
        <Route path="/Cart" element = {<Cart/>}/>
        <Route path="Home" element = { <Home/>}/>
       
      </Routes>
      <ToastContainer/>
    </div>
  );
}

export default App;
