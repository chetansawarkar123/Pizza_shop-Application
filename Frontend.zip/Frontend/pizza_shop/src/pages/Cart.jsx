 export function Cart(){
    return(
        <>
        <h1 className="title"> </h1>
        </>
    )
 }

 export default Cart 