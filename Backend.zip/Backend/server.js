const express = require('express')//Express is primarily used to build web applications 
// and APIs with ease by providing a lightweight and flexible framework for handling HTTP requests, defining routes, and managing middleware
const cors = require('cors') // without you cant able to use application outside your local machine
const morgan = require('morgan')//morgan for login purpose
const jwt = require('jsonwebtoken')
const config = require('./config')
const utils = require('./utils')

//create new react app
const app = express()
app.use(cors())
app.use(morgan('combined'))
app.use(express.json()) // for json body
app.use(express.urlencoded({extended: true}))

//configure protected routes 
// because no one can access the application unless his logged in for this we gives security of token, make it protected

app.use((request, response, next) => {
    const skipUrls = ['/user/signup', '/user/signin']
    if(skipUrls.findIndex(item => item == request.url) !=-1)//this kind a which not available here meaning of !=-1 
    {
     next()
    }
    //but its not sign in and sign up we ask a user to send a token
    else{
        const token = request.headers['token']
        if(!token){
            response.send(utils.createError('missing token'))
        }
        else {
         try {
            const payload = jwt.verify(token, config.secret)
            request.data = payload
            next()
         }   
         catch(ex){
            response.send(utils.createError('invalid token'))
         }
        }
    }
})

//add the routes
const userRouter = require('./routes/user')
const pizzaRouter = require('./routes/pizza')
const ordersRouter = require('./routes/orders')

app.use('/user', userRouter)
app.use('/pizza', pizzaRouter)
app.use('/orders', ordersRouter)

app.listen(4000, '0.0.0.0', () =>  {
    console.log('server started on port 4000')
})
